setwd("C:/Users/Savini/Downloads/Lab 05-20250904")
DeliveryTimes <- read.table("Exercise - Lab 05.txt", header = TRUE)

# View the first few rows
head(DeliveryTimes)

breaks_seq <- seq(20, 70, by = 6)


# Rename the column
colnames(DeliveryTimes) <- c("DeliveryTime")

# Now just use it directly
hist(DeliveryTimes$DeliveryTime,
     breaks = breaks_seq,
     right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency",
     col = "lightblue",
     border = "black")

hist_data <- hist(DeliveryTimes$DeliveryTime,
                  breaks = breaks_seq,
                  right = FALSE,
                  plot = FALSE)

cum_freq <- cumsum(hist_data$counts)

plot(hist_data$breaks[-1], cum_freq,
     type = "o", pch = 16, col = "blue",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency")
