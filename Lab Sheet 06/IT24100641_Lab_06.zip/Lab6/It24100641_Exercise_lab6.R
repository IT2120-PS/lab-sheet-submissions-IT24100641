#exercise 1
#i
#X ~ Binomial(n=50, p=0.85)
#ii
#at least 47 1-P(X<=46)
a = (1-pbinom(46,50,0.85,lower.tail = TRUE))
print(a)

#exercise 1
#i
#X: Number of customer calls received per hour
# X ~ Poisson(12)

#exactly 15 calls are received in an hour P(X=15)
b=dpois(15,12)
print(b)
