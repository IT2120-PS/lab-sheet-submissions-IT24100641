setwd("C:/Users/Savini/OneDrive - Sri Lanka Institute of Information Technology/Desktop/PS/Lab6")
# Question 01 - Binomial Distribution

# Part 1: Distribution of X
# X ~ Binomial(n=44, p=0.92)

print(dbinom(40,44,0.92))

# Part 3: P(X <= 35)

print(pbinom(37,44,0.92,lower.tail = FALSE))



# Part 3: P(X = 6)
dpois(6, 5)

# Part 4: P(X > 6)
ppois(6, 5, lower.tail = FALSE)

