setwd("C:/Users/Savini/Downloads/Lab04PS")
##Importing the data set 

data <- read.table("DATA 4.txt",header=TRUE,sep = " ")  

##view the file in a separate window 

fix(data)  

##Attach the file into R. So, you can call the variables by their names. 
attach (data)
##Part 2 
##Part (a)
##Obtaining Box Plots 

boxplot (X1, main="Box plot for Team Attendence", outline=TRUE, outpch=8, horizontal=TRUE) 
boxplot (X3,main="Box plot for Years", outline=TRUE, outpch=8, horizontal=TRUE)  
boxplot (X2,main="Box plot for Team Salary", outline=TRUE, outpch=8,horizontal=TRUE) 


##Obtaining Histogram 

hist(X1,ylab="Frequency",xlab="Team Attendence", main="Histogram for Team Attendence") 
hist(X2,ylab="Frequency",xlab="Team Salary", main="Histogram for Team Salary") 
hist(X3,ylab="Frequency",xlab="Years",main="Histogram for Years") 


#Stem & Leaf Plot 
stem(X1) 
stem(X2) 
stem(X3)

##Part (b) 
##Mean 

mean (X1) 
mean (X2) 
mean (X3)  

##Median 
median (X1) 
median (X2) 
median (X3)  

##Standard Deviation 
sd(X1) 
sd(X2) 
sd(X3)

##Part (c)
##Getting five number summary along with mean value 
summary(X1) 
summary(X2) 
summary(X3)  

##Getting only five number summary for X1 variable 

quantile(X1)  

##Calling first Quartile of X1 using index value 

quantile(X1) [2]  

##Calling third Quartile of X1 using index value 

quantile(X1) [4]

##Part (d) 
##Obtaining Inter Quartile Range (IQR) of each variable 

IQR(X1) 
IQR(X2) 
IQR(X3)

##Part 3
##Function to get the mode of a data set 

get.mode <- function(y){ 
  counts <- table(X3) 
names (counts [counts == max(counts)]) } 

##Obtaining the mode of a variable using the function defined above 

get.mode(X3)  

###Explanation on how each command inside the function works 
##Following command is to get the frequency table for the variable 

table(X3)  

##Following command will give the maximum frequency in the frequency table 

max (counts)  

##Following command will check whether frequencies in the frequency table equals 

##to the maximum frequency obtained 

counts == max (counts)  

##This extracts both value and the frequency which gives "TRUE" in earlier logical function 

counts [counts == max(counts)]  

##This extracts the value which gives maximum frequency (mode) in earlier logical function 

names (counts [counts == max(counts)])

