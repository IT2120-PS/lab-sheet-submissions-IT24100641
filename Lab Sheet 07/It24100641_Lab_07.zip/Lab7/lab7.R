setwd("C:/Users/Savini/OneDrive - Sri Lanka Institute of Information Technology/Desktop/PS/Lab7")

#1
#X ~ Uniform(a=0, b=40)
#P(10 <= X <= 25)

a= punif(25, min=0, max=40, lower.tail=TRUE) - punif(10, min=0, max=40, lower.tail=TRUE)
print(a)

#2
#X ~ Exponential(rate = 1/3)
#P(X <= 2)

b= pexp(2, rate=1/3, lower.tail=TRUE)
print(b)

#3
# i.P(X>130)
c=1 - pnorm(130, mean=100, sd=15, lower.tail=TRUE)
print(c)
#ii 95th percentile (Find b such that P(X <= b) = 0.95)
d=qnorm(0.95, mean=100, sd=15, lower.tail=TRUE)
print(d)















